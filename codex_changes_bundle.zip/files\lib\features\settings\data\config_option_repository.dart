import 'dart:convert';

import 'package:dartx/dartx.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hiddify/core/model/optional_range.dart';
import 'package:hiddify/core/model/region.dart';
import 'package:hiddify/core/preferences/general_preferences.dart';
import 'package:hiddify/core/utils/exception_handler.dart';
import 'package:hiddify/core/utils/json_converters.dart';
import 'package:hiddify/core/utils/preferences_utils.dart';
import 'package:hiddify/features/log/model/log_level.dart';
import 'package:hiddify/features/profile/data/profile_parser.dart';
import 'package:hiddify/features/settings/model/config_option_failure.dart';
import 'package:hiddify/features/site_routing/model/site_routing_mode.dart';
import 'package:hiddify/singbox/model/singbox_config_enum.dart';
import 'package:hiddify/singbox/model/singbox_config_option.dart';
import 'package:hiddify/singbox/model/singbox_rule.dart';
import 'package:hiddify/utils/utils.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

abstract class ConfigOptions {
  static final serviceMode = PreferencesNotifier.create<ServiceMode, String>(
    "service-mode",
    ServiceMode.defaultMode,
    mapFrom: (value) => ServiceMode.choices.firstWhere((e) => e.key == value),
    mapTo: (value) => value.key,
  );

  static final balancerStrategy = PreferencesNotifier.create<BalancerStrategy, String>(
    "balancer-strategy",
    BalancerStrategy.roundRobin,
    mapFrom: (value) => BalancerStrategy.values.firstWhere((e) => e.key == value),
    mapTo: (value) => value.key,
  );

  static final region = PreferencesNotifier.create<Region, String>(
    "region",
    Region.other,
    mapFrom: Region.values.byName,
    mapTo: (value) => value.name,
  );
  static final useXrayCoreWhenPossible = PreferencesNotifier.create<bool, bool>("use-xray-core-when-possible", false);
  static final blockAds = PreferencesNotifier.create<bool, bool>("block-ads", false);
  static final logLevel = PreferencesNotifier.create<LogLevel, String>(
    "log-level",
    LogLevel.warn,
    mapFrom: LogLevel.values.byName,
    mapTo: (value) => value.name,
  );

  static final resolveDestination = PreferencesNotifier.create<bool, bool>("resolve-destination", false);

  static final ipv6Mode = PreferencesNotifier.create<IPv6Mode, String>(
    "ipv6-mode",
    IPv6Mode.disable,
    mapFrom: (value) => IPv6Mode.values.firstWhere((e) => e.key == value),
    mapTo: (value) => value.key,
  );

  static final remoteDnsAddress = PreferencesNotifier.create<String, String>(
    "remote-dns-address",
    "tcp://8.8.8.8",
    possibleValues: List.of([
      "local",
      "tcp://8.8.8.8",
      "tcp://1.1.1.1",
      "https://1.1.1.1/dns-query",
      "https://dns.cloudflare.com/dns-query",
      "tcp://4.4.2.2",
    ]),
    validator: (value) => value.isNotBlank,
  );

  static final remoteDnsDomainStrategy = PreferencesNotifier.create<DomainStrategy, String>(
    "remote-dns-domain-strategy",
    DomainStrategy.auto,
    mapFrom: (value) => DomainStrategy.values.firstWhere((e) => e.key == value),
    mapTo: (value) => value.key,
  );

  static final directDnsAddress = PreferencesNotifier.create<String, String>(
    "direct-dns-address",
    "udp://1.1.1.1",
    possibleValues: List.of([
      "local",
      "udp://223.5.5.5",
      "udp://1.1.1.1",
      "udp://1.1.1.2",
      "tcp://1.1.1.1",
      "https://1.1.1.1/dns-query",
      "https://dns.cloudflare.com/dns-query",
      "4.4.2.2",
      "8.8.8.8",
    ]),
    defaultValueFunction: (ref) => switch (ref.read(region)) {
      Region.cn => "223.5.5.5",
      _ => "1.1.1.1",
    },
    validator: (value) => value.isNotBlank,
  );

  static final directDnsDomainStrategy = PreferencesNotifier.create<DomainStrategy, String>(
    "direct-dns-domain-strategy",
    DomainStrategy.auto,
    mapFrom: (value) => DomainStrategy.values.firstWhere((e) => e.key == value),
    mapTo: (value) => value.key,
  );

  static final mixedPort = PreferencesNotifier.create<int, int>(
    "mixed-port",
    12334,
    validator: (value) => isPort(value.toString()),
  );

  static final tproxyPort = PreferencesNotifier.create<int, int>(
    "tproxy-port",
    12335,
    validator: (value) => isPort(value.toString()),
  );
  static final redirectPort = PreferencesNotifier.create<int, int>(
    "redirect-port",
    12336,
    validator: (value) => isPort(value.toString()),
  );
  static final directPort = PreferencesNotifier.create<int, int>(
    "direct-port",
    12337,
    validator: (value) => isPort(value.toString()),
  );

  static final tunImplementation = PreferencesNotifier.create<TunImplementation, String>(
    "tun-implementation",
    TunImplementation.gvisor,
    mapFrom: TunImplementation.values.byName,
    mapTo: (value) => value.name,
  );

  static final mtu = PreferencesNotifier.create<int, int>("mtu", 1500);

  static final strictRoute = PreferencesNotifier.create<bool, bool>("strict-route", true);
  static final networkProfile = PreferencesNotifier.create<String, String>("network-profile", "stable_mobile");
  static final networkMtuMode = PreferencesNotifier.create<String, String>("network-mtu-mode", "fixed");
  static final fragmentMode = PreferencesNotifier.create<String, String>("fragment-mode", "default");
  static final profileDnsStrategy = PreferencesNotifier.create<String, String>("profile-dns-strategy", "default");

  static final connectionTestUrl = PreferencesNotifier.create<String, String>(
    "connection-test-url",
    "http://captive.apple.com/hotspot-detect.html",
    possibleValues: List.of([
      "http://connectivitycheck.gstatic.com/generate_204",
      "http://www.gstatic.com/generate_204",
      "https://www.gstatic.com/generate_204",
      "https://redirector.googlevideo.com/generate_204",
      "http://cp.cloudflare.com",
      "http://kernel.org",
      "http://detectportal.firefox.com",
      "http://captive.apple.com/hotspot-detect.html",
      "https://1.1.1.1",
      "http://1.1.1.1",
    ]),
    validator: (value) => value.isNotBlank && isUrl(value),
  );

  static final urlTestInterval = PreferencesNotifier.create<Duration, int>(
    "url-test-interval",
    const Duration(minutes: 10),
    mapFrom: const IntervalInSecondsConverter().fromJson,
    mapTo: const IntervalInSecondsConverter().toJson,
  );

  static final enableClashApi = PreferencesNotifier.create<bool, bool>("enable-clash-api", true);

  static final clashApiPort = PreferencesNotifier.create<int, int>(
    "clash-api-port",
    16756,
    validator: (value) => isPort(value.toString()),
  );

  static final bypassLan = PreferencesNotifier.create<bool, bool>("bypass-lan", false);

  static final allowConnectionFromLan = PreferencesNotifier.create<bool, bool>("allow-connection-from-lan", false);

  static final enableFakeDns = PreferencesNotifier.create<bool, bool>("enable-fake-dns", false);

  // static final enableDnsRouting = PreferencesNotifier.create<bool, bool>("enable-dns-routing", true);

  static final independentDnsCache = PreferencesNotifier.create<bool, bool>("independent-dns-cache", true);

  static final enableTlsFragment = PreferencesNotifier.create<bool, bool>("enable-tls-fragment", false);

  static final fragmentPackets = PreferencesNotifier.create<String, String>(
    "fragment-packets",
    "1-5",
    possibleValues: ["tlshello", "1-1", "1-2", "1-3", "1-4", "1-5"],
  );

  static final tlsFragmentSize = PreferencesNotifier.create<OptionalRange, String>(
    "tls-fragment-size",
    const OptionalRange(min: 10, max: 30),
    mapFrom: OptionalRange.parse,
    mapTo: const OptionalRangeJsonConverter().toJson,
  );

  static final tlsFragmentSleep = PreferencesNotifier.create<OptionalRange, String>(
    "tls-fragment-sleep",
    const OptionalRange(min: 2, max: 8),
    mapFrom: OptionalRange.parse,
    mapTo: const OptionalRangeJsonConverter().toJson,
  );

  static final enableTlsMixedSniCase = PreferencesNotifier.create<bool, bool>("enable-tls-mixed-sni-case", true);

  static final enableTlsPadding = PreferencesNotifier.create<bool, bool>("enable-tls-padding", false);

  static final tlsPaddingSize = PreferencesNotifier.create<OptionalRange, String>(
    "tls-padding-size",
    const OptionalRange(min: 1, max: 1500),
    mapFrom: OptionalRange.parse,
    mapTo: const OptionalRangeJsonConverter().toJson,
  );

  static final enableMux = PreferencesNotifier.create<bool, bool>("enable-mux", false);

  static final muxPadding = PreferencesNotifier.create<bool, bool>("mux-padding", false);

  static final muxMaxStreams = PreferencesNotifier.create<int, int>(
    "mux-max-streams",
    8,
    validator: (value) => value > 0,
  );

  static final muxProtocol = PreferencesNotifier.create<MuxProtocol, String>(
    "mux-protocol",
    MuxProtocol.h2mux,
    mapFrom: MuxProtocol.values.byName,
    mapTo: (value) => value.name,
  );

  static final enableWarp = PreferencesNotifier.create<bool, bool>("enable-warp", false);

  static final warpDetourMode = PreferencesNotifier.create<WarpDetourMode, String>(
    "warp-detour-mode",
    WarpDetourMode.warpOverProxy,
    mapFrom: WarpDetourMode.values.byName,
    mapTo: (value) => value.name,
  );

  static final warpLicenseKey = PreferencesNotifier.create<String, String>("warp-license-key", "");
  static final warp2LicenseKey = PreferencesNotifier.create<String, String>("warp2s-license-key", "");

  static final warpAccountId = PreferencesNotifier.create<String, String>("warp-account-id", "");
  static final warp2AccountId = PreferencesNotifier.create<String, String>("warp2-account-id", "");

  static final warpAccessToken = PreferencesNotifier.create<String, String>("warp-access-token", "");
  static final warp2AccessToken = PreferencesNotifier.create<String, String>("warp2-access-token", "");

  static final warpCleanIp = PreferencesNotifier.create<String, String>("warp-clean-ip", "auto");

  static final warpPort = PreferencesNotifier.create<int, int>(
    "warp-port",
    0,
    validator: (value) => isPort(value.toString()),
  );

  static final warpNoise = PreferencesNotifier.create<OptionalRange, String>(
    "warp-noise",
    const OptionalRange(min: 1, max: 3),
    mapFrom: (value) => OptionalRange.parse(value, allowEmpty: true),
    mapTo: const OptionalRangeJsonConverter().toJson,
  );
  static final warpNoiseMode = PreferencesNotifier.create<String, String>("warp-noise-mode", "m4");

  static final warpNoiseDelay = PreferencesNotifier.create<OptionalRange, String>(
    "warp-noise-delay",
    const OptionalRange(min: 10, max: 30),
    mapFrom: (value) => OptionalRange.parse(value, allowEmpty: true),
    mapTo: const OptionalRangeJsonConverter().toJson,
  );
  static final warpNoiseSize = PreferencesNotifier.create<OptionalRange, String>(
    "warp-noise-size",
    const OptionalRange(min: 10, max: 30),
    mapFrom: (value) => OptionalRange.parse(value, allowEmpty: true),
    mapTo: const OptionalRangeJsonConverter().toJson,
  );

  static final warpWireguardConfig = PreferencesNotifier.create<String, String>("warp-wireguard-config", "");
  static final warp2WireguardConfig = PreferencesNotifier.create<String, String>("warp2-wireguard-config", "");

  static final hasExperimentalFeatures = Provider.autoDispose<bool>((ref) {
    // final mode = ref.watch(serviceMode);
    // if (PlatformUtils.isDesktop && mode == ServiceMode.tun) {
    //   return true;
    // }
    // if (ref.watch(enableTlsFragment) || ref.watch(enableTlsMixedSniCase) || ref.watch(enableTlsPadding) || ref.watch(enableMux) || ref.watch(enableWarp) || ref.watch(bypassLan) || ref.watch(allowConnectionFromLan)) {
    //   return true;
    // }

    return false;
  });

  /// preferences to exclude from share and export
  static final privatePreferencesKeys = {
    "warp.license-key",
    "warp.access-token",
    "warp.account-id",
    "warp.wireguard-config",
    "warp2.license-key",
    "warp2.access-token",
    "warp2.account-id",
    "warp2.wireguard-config",
  };

  static final Map<String, StateNotifierProvider<PreferencesNotifier, dynamic>> preferences = {
    "region": region,
    "balancer-strategy": balancerStrategy,
    "block-ads": blockAds,
    "use-xray-core-when-possible": useXrayCoreWhenPossible,
    "service-mode": serviceMode,
    "log-level": logLevel,
    "resolve-destination": resolveDestination,
    "ipv6-mode": ipv6Mode,
    "remote-dns-address": remoteDnsAddress,
    "remote-dns-domain-strategy": remoteDnsDomainStrategy,
    "direct-dns-address": directDnsAddress,
    "direct-dns-domain-strategy": directDnsDomainStrategy,
    "mixed-port": mixedPort,
    "tproxy-port": tproxyPort,
    "direct-port": directPort,
    "redirect-port": redirectPort,
    "tun-implementation": tunImplementation,
    "mtu": mtu,
    "strict-route": strictRoute,
    "network-profile": networkProfile,
    "network-mtu-mode": networkMtuMode,
    "fragment-mode": fragmentMode,
    "profile-dns-strategy": profileDnsStrategy,
    "connection-test-url": connectionTestUrl,
    "url-test-interval": urlTestInterval,
    "clash-api-port": clashApiPort,
    "bypass-lan": bypassLan,
    "allow-connection-from-lan": allowConnectionFromLan,
    // "enable-dns-routing": enableDnsRouting,

    // mux
    // "mux.enable": enableMux,
    // "mux.padding": muxPadding,
    // "mux.max-streams": muxMaxStreams,
    // "mux.protocol": muxProtocol,

    // tls-tricks
    "tls-tricks.enable-fragment": enableTlsFragment,
    "tls-tricks.fragment-packets": fragmentPackets,
    "tls-tricks.fragment-size": tlsFragmentSize,
    "tls-tricks.fragment-sleep": tlsFragmentSleep,
    "tls-tricks.mixed-sni-case": enableTlsMixedSniCase,
    "tls-tricks.enable-padding": enableTlsPadding,
    "tls-tricks.padding-size": tlsPaddingSize,

    // warp
    "warp.enable": enableWarp,
    "warp.mode": warpDetourMode,
    "warp.license-key": warpLicenseKey,
    "warp.account-id": warpAccountId,
    "warp.access-token": warpAccessToken,
    "warp.clean-ip": warpCleanIp,
    "warp.clean-port": warpPort,
    "warp.noise": warpNoise,
    "warp.noise-size": warpNoiseSize,
    "warp.noise-mode": warpNoiseMode,
    "warp.noise-delay": warpNoiseDelay,
    "warp.wireguard-config": warpWireguardConfig,
    "warp2.license-key": warp2LicenseKey,
    "warp2.account-id": warp2AccountId,
    "warp2.access-token": warp2AccessToken,
    "warp2.wireguard-config": warp2WireguardConfig,
  };

  static final singboxConfigOptions = Provider<SingboxConfigOption>((ref) {
    final mode = ref.watch(serviceMode);
    final selectedRegion = ref.watch(region);
    final siteRoutingMode = ref.watch(Preferences.siteRoutingMode);
    final siteRoutingInclude = _normalizeWebsites(ref.watch(Preferences.includeSites));
    final siteRoutingExclude = _normalizeWebsites(ref.watch(Preferences.excludeSites));
    final rules = _buildSiteRoutingRules(
      mode: siteRoutingMode,
      include: siteRoutingInclude,
      exclude: siteRoutingExclude,
    );
    // final reg = ref.watch(Preferences.region.notifier).raw();

    return SingboxConfigOption(
      region: selectedRegion.name,
      balancerStrategy: ref.watch(balancerStrategy),
      blockAds: ref.watch(blockAds),
      useXrayCoreWhenPossible: ref.watch(useXrayCoreWhenPossible),
      executeConfigAsIs: false,
      logLevel: ref.watch(logLevel),
      resolveDestination: ref.watch(resolveDestination),
      ipv6Mode: ref.watch(ipv6Mode),
      remoteDnsAddress: ref.watch(remoteDnsAddress),
      remoteDnsDomainStrategy: ref.watch(remoteDnsDomainStrategy),
      directDnsAddress: ref.watch(directDnsAddress),
      directDnsDomainStrategy: ref.watch(directDnsDomainStrategy),
      mixedPort: ref.watch(mixedPort),
      tproxyPort: ref.watch(tproxyPort),
      directPort: ref.watch(directPort),
      redirectPort: ref.watch(redirectPort),
      tunImplementation: ref.watch(tunImplementation),
      mtu: ref.watch(mtu),
      strictRoute: ref.watch(strictRoute),
      networkProfile: ref.watch(networkProfile),
      networkMtuMode: ref.watch(networkMtuMode),
      fragmentMode: ref.watch(fragmentMode),
      profileDnsStrategy: ref.watch(profileDnsStrategy),
      connectionTestUrl: ref.watch(connectionTestUrl),
      urlTestInterval: ref.watch(urlTestInterval),
      enableClashApi: ref.watch(enableClashApi),
      clashApiPort: ref.watch(clashApiPort),
      enableTun: mode == ServiceMode.tun,
      // enableTunService: mode == false, //ServiceMode.tunService,
      setSystemProxy: mode == ServiceMode.systemProxy,
      bypassLan: ref.watch(bypassLan),
      allowConnectionFromLan: ref.watch(allowConnectionFromLan),
      enableFakeDns: ref.watch(enableFakeDns),
      // enableDnsRouting: ref.watch(enableDnsRouting),
      independentDnsCache: ref.watch(independentDnsCache),
      siteRoutingMode: siteRoutingMode.name,
      siteRoutingInclude: siteRoutingInclude,
      siteRoutingExclude: siteRoutingExclude,
      // mux: SingboxMuxOption(
      //   enable: ref.watch(enableMux),
      //   padding: ref.watch(muxPadding),
      //   maxStreams: ref.watch(muxMaxStreams),
      //   protocol: ref.watch(muxProtocol),
      // ),
      tlsTricks: SingboxTlsTricks(
        enableFragment: ref.watch(enableTlsFragment),
        fragmentSize: ref.watch(tlsFragmentSize),
        fragmentSleep: ref.watch(tlsFragmentSleep),
        mixedSniCase: ref.watch(enableTlsMixedSniCase),
        enablePadding: ref.watch(enableTlsPadding),
        paddingSize: ref.watch(tlsPaddingSize),
      ),
      warp: SingboxWarpOption(
        enable: ref.watch(enableWarp),
        mode: ref.watch(warpDetourMode),
        wireguardConfig: ref.watch(warpWireguardConfig),
        licenseKey: ref.watch(warpLicenseKey),
        accountId: ref.watch(warpAccountId),
        accessToken: ref.watch(warpAccessToken),
        cleanIp: ref.watch(warpCleanIp),
        cleanPort: ref.watch(warpPort),
        noise: ref.watch(warpNoise),
        noiseMode: ref.watch(warpNoiseMode),
        noiseSize: ref.watch(warpNoiseSize),
        noiseDelay: ref.watch(warpNoiseDelay),
      ),
      warp2: SingboxWarpOption(
        enable: ref.watch(enableWarp),
        mode: ref.watch(warpDetourMode),
        wireguardConfig: ref.watch(warp2WireguardConfig),
        licenseKey: ref.watch(warp2LicenseKey),
        accountId: ref.watch(warp2AccountId),
        accessToken: ref.watch(warp2AccessToken),
        cleanIp: ref.watch(warpCleanIp),
        cleanPort: ref.watch(warpPort),
        noise: ref.watch(warpNoise),
        noiseMode: ref.watch(warpNoiseMode),
        noiseSize: ref.watch(warpNoiseSize),
        noiseDelay: ref.watch(warpNoiseDelay),
      ),
      rules: rules,
    );
  });

  static List<String> _normalizeWebsites(List<String> rawValues) {
    final normalized = <String>[];
    for (final value in rawValues) {
      var candidate = value.trim().toLowerCase();
      if (candidate.isEmpty || normalized.contains(candidate)) continue;
      candidate = candidate
          .replaceAll(RegExp(r'\s+'), '')
          .replaceFirst(RegExp('^[a-z][a-z0-9+.-]*://'), '')
          .replaceFirst(RegExp('^/+'), '')
          .split('/')[0]
          .split('?')[0]
          .split('#')[0]
          .replaceFirst(RegExp(r'^\*\.'), '')
          .replaceFirst(RegExp(r'^www\.'), '')
          .replaceFirst(RegExp(r'^\.'), '')
          .replaceFirst(RegExp(r'\.$'), '');
      if (candidate.isEmpty || !isDomain(candidate) || normalized.contains(candidate)) continue;
      normalized.add(candidate);
    }
    return normalized;
  }

  static List<SingboxRule> _buildSiteRoutingRules({
    required SiteRoutingMode mode,
    required List<String> include,
    required List<String> exclude,
  }) {
    final compactInclude = include;
    final compactExclude = exclude;
    return switch (mode) {
      SiteRoutingMode.off => const <SingboxRule>[],
      SiteRoutingMode.include when compactInclude.isNotEmpty => <SingboxRule>[SingboxRule(domains: compactInclude)],
      SiteRoutingMode.exclude when compactExclude.isNotEmpty => <SingboxRule>[
        SingboxRule(domains: compactExclude, outbound: RuleOutbound.bypass),
      ],
      _ => const <SingboxRule>[],
    };
  }
}

class ConfigOptionRepository with ExceptionHandler, InfraLogger {
  ConfigOptionRepository({required this.preferences, required SingboxConfigOption Function() getConfigOptions})
    : _getConfigOptions = getConfigOptions;

  final SharedPreferences preferences;
  final SingboxConfigOption Function() _getConfigOptions;

  Either<ConfigOptionFailure, SingboxConfigOption> fullOptions() =>
      Either.tryCatch(() => _getConfigOptions(), ConfigOptionFailure.unexpected);

  Either<ConfigOptionFailure, SingboxConfigOption> fullOptionsOverrided(String? profileOverride) =>
      Either.tryCatch(() => _getConfigOptions(), ConfigOptionFailure.unexpected).flatMap(
        (options) => Either.tryCatch(() {
          final json = ProfileParser.applyProfileOverride(options.toJson(), profileOverride);
          return SingboxConfigOption.fromJson(_normalizeConfigJsonForFromJson(json));
        }, ConfigOptionFailure.unexpected),
      );

  static Map<String, dynamic> _normalizeConfigJsonForFromJson(Map<String, dynamic> json) {
    final normalized = Map<String, dynamic>.from(json);
    normalized['site-routing-include'] = _normalizeStringList(normalized['site-routing-include']);
    normalized['site-routing-exclude'] = _normalizeStringList(normalized['site-routing-exclude']);
    normalized['rules'] = _normalizeRuleList(normalized['rules']);
    return normalized;
  }

  static List<String> _normalizeStringList(dynamic raw) {
    if (raw is List) {
      return raw.map((e) => e.toString()).where((e) => e.isNotBlank).toList();
    }
    if (raw is String) {
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return const <String>[];
      if (trimmed.startsWith('[')) {
        try {
          final decoded = jsonDecode(trimmed);
          if (decoded is List) {
            return decoded.map((e) => e.toString()).where((e) => e.isNotBlank).toList();
          }
        } catch (_) {
          // Fallback to token split below.
        }
      }
      return trimmed.split(RegExp(r'[;,\n]+')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    }
    return const <String>[];
  }

  static List<Map<String, dynamic>> _normalizeRuleList(dynamic raw) {
    if (raw is List) {
      return raw.whereType<Map>().map((e) => e.map((k, v) => MapEntry(k.toString(), v))).toList();
    }
    if (raw is String) {
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return const <Map<String, dynamic>>[];
      try {
        final decoded = jsonDecode(trimmed);
        if (decoded is List) {
          return decoded.whereType<Map>().map((e) => e.map((k, v) => MapEntry(k.toString(), v))).toList();
        }
      } catch (_) {
        // Ignore invalid JSON and fall back to empty rule list.
      }
    }
    return const <Map<String, dynamic>>[];
  }
}
